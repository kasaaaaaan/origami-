まいにち おりがみ(Fire HD 8 / Chrome 用)

■ ファイル
index.html / manifest.webmanifest / sw.js / icon-*.png
→ 6つ すべてを 同じ場所に置いてください。

■ GitHub Pages で公開する手順
1. github.com でアカウントを作る(無料)
2. 右上「+」→「New repository」→ 名前を「origami」などにして Public で作成
3. 「uploading an existing file」から、6つのファイルをまとめてドラッグして「Commit changes」
4. Settings → Pages → Branch を「main」「/(root)」にして Save
5. 数分後に表示される https://(ユーザー名).github.io/origami/ が アプリのURL

■ Fire HD 8 に入れる
1. Chrome で上のURLを開く
2. 右上「︙」→「アプリをインストール」または「ホーム画面に追加」
3. アイコンから開く(一度開けば、ネットがなくても動きます)

■ 注意
・記録・写真・動画は Fire HD 8 の中(Chrome)に保存されます。
  Chrome の「サイトデータを削除」やアンインストールで消えます。
・おとなモード(🔒おとな を長押し)→ スタンプ画面で「バックアップ」を
  ときどき保存してください(動画は含まれません)。

■ アップデートするとき
1. 新しい index.html をGitHubに上書きアップロード
2. sw.js の VERSION を "v2" のように1つ増やしてアップロード
3. Fire でアプリを2回ほど開き直すと新しい版になります(記録は消えません)
